console.log("[LOADED] std-mod is now loaded")

export {}