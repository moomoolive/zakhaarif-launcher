console.log("hi")

console.log("my meta yeah", import.meta.url)